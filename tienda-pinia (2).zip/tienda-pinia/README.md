# TecnoStore · Tienda virtual con Pinia (Vue 3)

Misma tienda de la versión con props/emits, pero el estado compartido vive en **stores de Pinia**
en lugar de `App.vue`. Los componentes leen y modifican el estado directamente desde los stores.

## Ejecutar
```bash
npm install
npm run dev
```

## Estructura
```
src/
├── main.js                  # createPinia() y app.use(pinia)
├── App.vue                  # solo compone la página (sin estado propio)
├── stores/
│   ├── productos.js         # state: productos
│   ├── carrito.js           # state: items, abierto | getters: cantidadItems, vacio, subtotalSinDescuento, descuentos, total
│   │                        # actions: agregarProducto, incrementar, decrementar, eliminar, vaciar, alternar, cerrar, finalizarCompra
│   └── factura.js           # state: visible, numero, fecha, consecutivo | getters: sinDescuento, subtotal, totalDescuentos, iva, totalPagar
│                            # actions: generar, ocultar, nuevaCompra
├── components/
│   ├── AppHeader.vue        # prop: nombreTienda | usa carrito store (badge y botón)
│   ├── ListaProductos.vue   # usa productos store
│   ├── ProductoCard.vue     # prop: producto | usa carrito.agregarProducto
│   ├── CarritoCompra.vue    # usa carrito store
│   ├── FacturaCompra.vue    # usa carrito y factura stores
│   └── AppFooter.vue        # props: nombreTienda, anio, contacto
└── utils/formato.js         # Intl.NumberFormat("es-CO", COP) y fórmula del descuento
```

## Props/emits vs Pinia
| Antes (props/emits)                          | Ahora (Pinia)                                  |
|----------------------------------------------|------------------------------------------------|
| `ref` de carrito, factura, etc. en `App.vue` | `ref` dentro de `defineStore` (state)          |
| `computed` de totales en cada componente     | `computed` dentro del store (getters)          |
| funciones en `App.vue` + `emit(...)`         | funciones del store (actions) llamadas directo |
