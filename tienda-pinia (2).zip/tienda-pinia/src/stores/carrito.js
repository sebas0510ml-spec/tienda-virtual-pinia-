import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { calcularValorConDescuento } from '../utils/formato'
import { useFacturaStore } from './factura'

// Store del carrito: items [{ producto, cantidad }], visibilidad y totales.
export const useCarritoStore = defineStore('carrito', () => {
  // ----- state -----
  const items = ref([])
  const abierto = ref(false)

  // ----- getters -----
  const cantidadItems = computed(() =>
    items.value.reduce((acc, it) => acc + it.cantidad, 0)
  )
  const vacio = computed(() => items.value.length === 0)
  const subtotalSinDescuento = computed(() =>
    items.value.reduce((a, i) => a + i.producto.valor * i.cantidad, 0)
  )
  const total = computed(() =>
    items.value.reduce((a, i) => a + calcularValorConDescuento(i.producto) * i.cantidad, 0)
  )
  const descuentos = computed(() => subtotalSinDescuento.value - total.value)

  // ----- actions -----
  function agregarProducto(producto) {
    const existente = items.value.find((it) => it.producto.id === producto.id)
    if (existente) existente.cantidad++
    else items.value.push({ producto, cantidad: 1 })
    useFacturaStore().ocultar()
  }

  function incrementar(id) {
    const it = items.value.find((i) => i.producto.id === id)
    if (it) it.cantidad++
  }

  function decrementar(id) {
    const it = items.value.find((i) => i.producto.id === id)
    if (it && it.cantidad > 1) it.cantidad--
  }

  function eliminar(id) {
    items.value = items.value.filter((i) => i.producto.id !== id)
  }

  function vaciar() {
    items.value = []
  }

  function alternar() {
    abierto.value = !abierto.value
  }

  function cerrar() {
    abierto.value = false
  }

  function finalizarCompra() {
    if (vacio.value) return
    cerrar()
    useFacturaStore().generar()
  }

  return {
    items, abierto,
    cantidadItems, vacio, subtotalSinDescuento, total, descuentos,
    agregarProducto, incrementar, decrementar, eliminar, vaciar, alternar, cerrar, finalizarCompra,
  }
})
