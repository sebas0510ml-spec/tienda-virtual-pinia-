import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { useCarritoStore } from './carrito'

export const IVA = 0.19

// Store de la factura: numeración, fecha, visibilidad y totales con IVA.
export const useFacturaStore = defineStore('factura', () => {
  const visible = ref(false)
  const numero = ref('')
  const fecha = ref('')
  const consecutivo = ref(0)

  // Los totales se derivan del carrito (un store puede leer otro store).
  const sinDescuento = computed(() => useCarritoStore().subtotalSinDescuento)
  const subtotal = computed(() => useCarritoStore().total)
  const totalDescuentos = computed(() => sinDescuento.value - subtotal.value)
  const iva = computed(() => Math.round(subtotal.value * IVA))
  const totalPagar = computed(() => subtotal.value + iva.value)

  function generar() {
    consecutivo.value++
    numero.value = 'FAC-' + String(consecutivo.value).padStart(4, '0')
    fecha.value = new Date().toLocaleDateString('es-CO')
    visible.value = true
    setTimeout(() => document.getElementById('factura')?.scrollIntoView({ behavior: 'smooth' }), 50)
  }

  function ocultar() {
    visible.value = false
  }

  function nuevaCompra() {
    useCarritoStore().vaciar()
    ocultar()
  }

  return {
    visible, numero, fecha, consecutivo,
    sinDescuento, subtotal, totalDescuentos, iva, totalPagar,
    generar, ocultar, nuevaCompra,
  }
})
