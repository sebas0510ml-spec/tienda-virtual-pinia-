import { ref } from 'vue'
import { defineStore } from 'pinia'

// Store del catálogo: solo contiene los datos de los productos.
export const useProductosStore = defineStore('productos', () => {
  const productos = ref([
    { id: 1, imagen: 'https://thegioiso365.vn/wp-content/uploads/2026/07/hp-omnibook-x-flip-14-2in1-2026.webp', descripcion: 'Portátil 15" 16 GB RAM, 512 GB SSD', valor: 2899000, descuento: 15 },
    { id: 2, imagen: 'https://i0.wp.com/www.madboxpc.com/wp-content/uploads/2012/03/review-00933.jpg?ssl=1', descripcion: 'Ps vita Funcional Con Caja', valor: 329900, descuento: 10 },
    { id: 3, imagen: 'https://http2.mlstatic.com/D_NQ_NP_2X_898850-MLA111046502659_042026-F.webp', descripcion: 'Audífonos inalámbricos con cancelación de ruido', valor: 420000, descuento: 25 },
    { id: 4, imagen: 'https://http2.mlstatic.com/D_NQ_NP_2X_781119-MLA92918690806_092025-F.webp', descripcion: 'Reloj inteligente deportivo con GPS', valor: 203300, descuento: 0 },
    { id: 5, imagen: 'https://http2.mlstatic.com/D_NQ_NP_2X_764370-MLA95934554983_102025-F.webp', descripcion: 'Mouse ergonómico inalámbrico', valor: 89900, descuento: 20 },
    { id: 6, imagen: 'https://http2.mlstatic.com/D_NQ_NP_2X_848985-CBT119610765679_102026-F.webp', descripcion: 'Tablet 10" 64 GB con lápiz', valor: 454200, descuento: 15 },
    { id: 7, imagen: 'https://http2.mlstatic.com/D_NQ_NP_2X_685190-MLA99496730742_112025-F.webp', descripcion: 'Teclado mecánico retroiluminado', valor: 200000, descuento: 12 },
    { id: 8, imagen: 'https://exitocol.vtexassets.com/arquivos/ids/29258877/monitor-dell-27-pulgadas-75-hz-5ms-full-hd.jpg?v=638889147074700000', descripcion: 'Monitor 27" Full HD 75 Hz', valor: 780000, descuento: 0 },
  ])

  return { productos }
})
