<script setup>
import { formatoCOP, calcularValorConDescuento } from '../utils/formato'
import { useCarritoStore } from '../stores/carrito'

const carrito = useCarritoStore()
</script>

<template>
  <div class="carrito-overlay" @click="carrito.cerrar()"></div>
  <aside class="carrito" @click.stop>
    <div class="carrito-header">
      <h2>Tu carrito</h2>
      <button class="btn-cerrar" @click="carrito.cerrar()">✕</button>
    </div>

    <p v-if="carrito.vacio" class="vacio">Tu carrito está vacío. ¡Agrega algún producto!</p>

    <ul v-else class="lista-carrito">
      <li v-for="it in carrito.items" :key="it.producto.id" class="item">
        <img :src="it.producto.imagen" :alt="it.producto.descripcion" />
        <div class="item-info">
          <strong>{{ it.producto.descripcion }}</strong>
          <small>{{ formatoCOP(calcularValorConDescuento(it.producto)) }} c/u</small>
        </div>
        <div class="cantidad">
          <button :disabled="it.cantidad <= 1" @click="carrito.decrementar(it.producto.id)">−</button>
          <span>{{ it.cantidad }}</span>
          <button @click="carrito.incrementar(it.producto.id)">+</button>
          <button class="x" @click="carrito.eliminar(it.producto.id)">✕</button>
        </div>
      </li>
    </ul>

    <dl class="totales">
      <div><dt>Subtotal sin descuento</dt><dd>{{ formatoCOP(carrito.subtotalSinDescuento) }}</dd></div>
      <div class="rojo"><dt>Descuentos</dt><dd>− {{ formatoCOP(carrito.descuentos) }}</dd></div>
      <div class="total"><dt>Total</dt><dd>{{ formatoCOP(carrito.total) }}</dd></div>
    </dl>

    <button class="btn" :disabled="carrito.vacio" @click="carrito.finalizarCompra()">Finalizar compra</button>
  </aside>
</template>
