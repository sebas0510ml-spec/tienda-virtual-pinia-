<script setup>
import { useCarritoStore } from '../stores/carrito'

defineProps({
  nombreTienda: { type: String, required: true },
})
const carrito = useCarritoStore()
</script>

<template>
  <header class="header">
    <div class="contenedor header-in">
      <div class="logo"><span>{{ nombreTienda.charAt(0) }}</span> {{ nombreTienda }}</div>
      <nav class="nav">
        <a href="#">Inicio</a>
      </nav>
      <button class="btn-carrito" @click="carrito.alternar()">
        🛒 Carrito <span class="badge">{{ carrito.cantidadItems }}</span>
      </button>
    </div>
  </header>
</template>
