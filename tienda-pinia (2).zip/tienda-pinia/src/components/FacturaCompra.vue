<script setup>
import { formatoCOP, calcularValorConDescuento } from '../utils/formato'
import { useCarritoStore } from '../stores/carrito'
import { useFacturaStore } from '../stores/factura'

const carrito = useCarritoStore()
const factura = useFacturaStore()
</script>

<template>
  <section class="factura">
    <div class="factura-cab">
      <div>
        <h2>Factura de compra</h2>
        <small>TecnoStore S.A.S. · NIT 900.000.000-0</small>
      </div>
      <div class="factura-num">
        <div>N.º <strong>{{ factura.numero }}</strong></div>
        <div>Fecha: {{ factura.fecha }}</div>
      </div>
    </div>

    <div class="tabla-scroll">
      <table>
        <thead>
          <tr>
            <th>Descripción</th><th>Cant.</th><th>Valor unit.</th>
            <th>Desc.</th><th>Valor c/desc.</th><th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="it in carrito.items" :key="it.producto.id">
            <td>{{ it.producto.descripcion }}</td>
            <td>{{ it.cantidad }}</td>
            <td>{{ formatoCOP(it.producto.valor) }}</td>
            <td>{{ it.producto.descuento }}%</td>
            <td>{{ formatoCOP(calcularValorConDescuento(it.producto)) }}</td>
            <td><strong>{{ formatoCOP(calcularValorConDescuento(it.producto) * it.cantidad) }}</strong></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="factura-pie">
      <button class="btn btn-sec" @click="factura.nuevaCompra()">Nueva compra</button>
      <dl class="totales">
        <div><dt>Total sin descuento</dt><dd>{{ formatoCOP(factura.sinDescuento) }}</dd></div>
        <div class="rojo"><dt>Total descuentos</dt><dd>− {{ formatoCOP(factura.totalDescuentos) }}</dd></div>
        <div><dt>Subtotal</dt><dd>{{ formatoCOP(factura.subtotal) }}</dd></div>
        <div><dt>IVA (19 %)</dt><dd>{{ formatoCOP(factura.iva) }}</dd></div>
        <div class="total"><dt>Total a pagar</dt><dd>{{ formatoCOP(factura.totalPagar) }}</dd></div>
      </dl>
    </div>
  </section>
</template>
