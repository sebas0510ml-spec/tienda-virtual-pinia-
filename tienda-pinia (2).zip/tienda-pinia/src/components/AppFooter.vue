<script setup>
defineProps({
  nombreTienda: { type: String, required: true },
  anio: { type: Number, required: true },
  contacto: { type: String, default: '' },
})
</script>

<template>
  <footer class="footer">
    <div class="contenedor footer-in">
      <div>
        <strong>{{ nombreTienda }}</strong>
        <p>Proyecto académico · Fundamentos de programación con Vue 3 y Pinia</p>
      </div>
      <div>
        <strong>Contacto</strong>
        <p>{{ contacto }}</p>
      </div>
      <div>
        <strong>© {{ anio }}</strong>
        <p>Todos los derechos reservados</p>
      </div>
    </div>
  </footer>
</template>
