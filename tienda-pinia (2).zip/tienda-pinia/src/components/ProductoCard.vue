<script setup>
import { computed } from 'vue'
import { formatoCOP, calcularValorConDescuento } from '../utils/formato'
import { useCarritoStore } from '../stores/carrito'

const props = defineProps({
  producto: {
    type: Object,
    required: true,
    validator: (p) => p.descuento >= 0 && p.descuento <= 100,
  },
})
const carrito = useCarritoStore()

const tieneDescuento = computed(() => props.producto.descuento > 0)
const valorConDescuento = computed(() => calcularValorConDescuento(props.producto))
const ahorro = computed(() => props.producto.valor - valorConDescuento.value)
</script>

<template>
  <article class="card">
    <div class="card-img">
      <span v-if="tieneDescuento" class="etiqueta">-{{ producto.descuento }}%</span>
      <img :src="producto.imagen" :alt="producto.descripcion" />
    </div>
    <h3>{{ producto.descripcion }}</h3>
    <p v-if="tieneDescuento" class="precio-tachado">{{ formatoCOP(producto.valor) }}</p>
    <p v-else class="precio-regular">Precio regular</p>
    <p class="precio-final">{{ formatoCOP(valorConDescuento) }}</p>
    <p v-if="tieneDescuento" class="ahorro">Ahorras {{ formatoCOP(ahorro) }}</p>
    <button class="btn" @click="carrito.agregarProducto(producto)">Comprar</button>
  </article>
</template>
