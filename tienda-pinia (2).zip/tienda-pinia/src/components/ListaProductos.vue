<script setup>
import ProductoCard from './ProductoCard.vue'
import { useProductosStore } from '../stores/productos'

const store = useProductosStore()
</script>

<template>
  <section class="catalogo">
    <div class="catalogo-titulo">
      <h2>Catálogo</h2>
      <span>{{ store.productos.length }} productos</span>
    </div>
    <div class="grid">
      <ProductoCard v-for="p in store.productos" :key="p.id" :producto="p" />
    </div>
  </section>
</template>
