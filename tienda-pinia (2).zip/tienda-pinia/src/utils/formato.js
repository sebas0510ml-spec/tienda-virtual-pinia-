const cop = new Intl.NumberFormat('es-CO', {
  style: 'currency',
  currency: 'COP',
  maximumFractionDigits: 0,
})

export const formatoCOP = (n) => cop.format(n)

// valorConDescuento = valor × (1 − descuento / 100)
export const calcularValorConDescuento = (p) =>
  Math.round(p.valor * (1 - p.descuento / 100))
