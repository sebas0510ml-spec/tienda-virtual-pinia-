<script setup>
import AppHeader from './components/AppHeader.vue'
import ListaProductos from './components/ListaProductos.vue'
import CarritoCompra from './components/CarritoCompra.vue'
import FacturaCompra from './components/FacturaCompra.vue'
import AppFooter from './components/AppFooter.vue'
import { useCarritoStore } from './stores/carrito'
import { useFacturaStore } from './stores/factura'

// El estado vive en los stores de Pinia; App.vue solo compone la página.
const carrito = useCarritoStore()
const factura = useFacturaStore()
</script>

<template>
  <AppHeader nombre-tienda="TecnoEntretenimiento" />

  <main class="contenedor">
    <div class="layout">
      <ListaProductos />
      <CarritoCompra v-if="carrito.abierto" />
    </div>

    <FacturaCompra v-if="factura.visible" id="factura" />
  </main>

  <AppFooter nombre-tienda="TecnoEntretenimiento" :anio="new Date().getFullYear()" contacto="Carlos Velandia / Sebastian Mercado" />
</template>
